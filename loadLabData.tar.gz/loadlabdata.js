var xlsxj = require("xlsx-to-json");
var mysql = require('mysql');
var http = require('http');
var https = require('https');
var fs = require('fs');
var readline = require('readline');
var google = require('googleapis');
var googleAuth = require('google-auth-library');
//var sheetEvents = [];
var connection;
var config;
var SHEETS = {};
SHEETS.sheetnames = [];
var DEBUG_LEVEL;
var authToken = null;

const SEVERITY = {'clear':'0','indeterminate':'1','warning':'2','minor':'3','major':4,'critical':'5'};

const groups = ['EndUser','All','Servers','Network','Application','Database','Storage','Desktop','Cloud','Other'];

var args = process.argv.slice(2);
// Inputs
var DEMO_CONFIG = '/usr/share/moogsoft/bin/utils/labdata.conf';

// console.log('Reading Config File "' + DEMO_CONFIG + '"');
//Read the client secret json to get credentials
if(args && args.length > 0) {
    fs.readFile(DEMO_CONFIG, function (err, fileconfig) {
        if (err) {
            console.log('ERROR: No Config File Found');
            console.log('Extended ERROR: ' + err);
        }
        else {
            config = JSON.parse(fileconfig);
            //showConfig();
            connection = mysql.createConnection(config.sqlconfig);
            DEBUG_LEVEL = config.debug;
            useLocalXLSX = config.uselocal;

            if (config.uselocal === true) {
                // get event data from local xlsx file
                if(config.labs.validNames.indexOf(args[0])>=0) {
                    SHEETS.sheetnames.push(args[0]);
                    //SHEETS = config.sheets;
                    if (DEBUG_LEVEL == 3) console.log('Sheets required are: ' + JSON.stringify(SHEETS));
                    processSheets(SHEETS, function (err, returnedEvents) {
                        if (DEBUG_LEVEL > 0) console.log('All sheets processed - Current array is ' + JSON.stringify(returnedEvents));
                        // process events array
                        processEvents(returnedEvents);
                    });
                }
                else {
                    console.log('You Must specifiy a valid lab name.');
                    console.log('Lab Specified "' + args + '" does not exist or is not approved for this course.');
                    console.log('Valid labs for this cource include: ' + config.labs.validNames);
                }
            }
            else {
                // get data from google sheets
                console.log('Using google sheet event data');
                readGoogleSecret();
            }
        }
    });
}
else {
    console.log('You Must specifiy a valid lab name.');
    console.log('Lab Specified "' + args + '" does not exist or is not approved for this course.');
    console.log('Valid labs for this cource include: ' + config.labs.validNames);}

// get events from local xlsx file
// use sheets defintion in config to specify spreadsheet tabs to use
function processSheets(SHEETS, callback) {
    var sheetEvents = [];
    var numSheetsProcessed = 0;
    //var sheetnames = SHEETS.sheetnames;

    for (var s = 0, sheetLen = SHEETS.sheetnames.length; s < sheetLen; s++) {
        console.log('Lab data being processed is ' + SHEETS.sheetnames[s]);

        // read xlsx spreedsheet sheets into json object array
        xlsxj({
            input: "/usr/share/moogsoft/bin/utils/labdata.xlsx",
            //output: "output.json"
            output: null,
           sheet: SHEETS.sheetnames[s]
        }, function(err, result) {
            if(err) {
                console.error(err);
            }else {
                // process each event and build out events list
                for (var i = 0, len = result.length; i < len; i++) {
                    sheetEvents.push(result[i]);
                    // check for all records being processed and update number
                    if (i === result.length-1) { numSheetsProcessed++; }
                }

                if (numSheetsProcessed === SHEETS.sheetnames.length) { callback(null, sheetEvents); }
            }
        });

    }
}

/**
 * Read the client secret json to get credentials, and then execute the
 * given callback function.
 * @function readSecret
 * @requires fs
 */
function readGoogleSecret(){
    var functionName = 'readSecret: ';
    if (DEBUG_LEVEL == 3) console.log(functionName + 'Reading Client Secret "' + config.clientsecret + '"');
    fs.readFile(config.clientsecret, function processClientSecrets(err, content) {
        if (err) {
            console.log('Error loading client secret file: ' + err);
            console.log('This file is downloaded from the OAuth client ID - Type Other ');
            return;
        }
        // Authorize a client with the loaded credentials, then call the
        // Google Apps Script Execution API.
        authorize(JSON.parse(content), callAppsScript);
    });
}

/**
 * Create an OAuth2 client with the given credentials, and then execute the
 * given callback function.
 * @callback authorize
 * @param {Object} credentials The authorization client credentials.
 * @param {function} callback The callback to call with the authorized client.
 * @requires fs
 *
 */
function authorize(credentials, callback) {
    var functionName = 'authorize: ';
    if (DEBUG_LEVEL == 3) console.log(functionName + 'Authorizing... ');
    var clientSecret = credentials.installed.client_secret;
    var clientId = credentials.installed.client_id;
    var redirectUrl = credentials.installed.redirect_uris[0];
    var auth = new googleAuth();
    var oauth2Client = new auth.OAuth2(clientId, clientSecret, redirectUrl);

    // Check if we have previously stored a token.
    if (DEBUG_LEVEL == 2) console.log('Trying to read auth token "' + config.authtoken + '"');
    fs.readFile(config.authtoken, function(err, token) {
        if (err) {
            getNewToken(oauth2Client, callback);
        } else {
            oauth2Client.credentials = JSON.parse(token);
            callback(oauth2Client);
        }
    });
}

/**
 * Get and store new token after prompting for user authorization, and then
 * execute the given callback with the authorized OAuth2 client.
 *
 * @param {google.auth.OAuth2} oauth2Client The OAuth2 client to get token for.
 * @param {getEventsCallback} callback The callback to call with the authorized
 *     client.
 */
function getNewToken(oauth2Client, callback) {
    var functionName = 'getNewToken: ';
    if (DEBUG_LEVEL == 3) console.log(functionName + 'Getting token... ');
    var authUrl = oauth2Client.generateAuthUrl({
        access_type: 'offline',
        scope: config.scopes
    });
    if (DEBUG_LEVEL >= 2) console.log('Authorize this app by visiting this url: ', authUrl);
    var rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question('Enter the code from that page here: ', function(code) {
        rl.close();
        oauth2Client.getToken(code, function(err, token) {
            /*if (err) {
             console.log(functionName + 'Error while trying to retrieve access token', err);
             return;
             }*/
            oauth2Client.credentials = token;
            storeToken(token);
            callback(oauth2Client);
        });
    });
}

/**
 * Store token to disk be used in later program executions.
 *
 * @param {Object} token The token to store to disk.
 */
function storeToken(token) {
    var functionName = 'storeToken: ';
    if (DEBUG_LEVEL == 3) console.log(functionName + 'storeToken... ');
    try {
        fs.mkdirSync(TOKEN_DIR);
    } catch (err) {
        /*if (err.code !== 'EXIST') {
         throw err;
         }*/
    }
    fs.writeFile(config.authtoken, JSON.stringify(token));
    if (DEBUG_LEVEL >= 1) console.log('Token stored to ' + config.authtoken);
}

/**
 * Call an Apps Script function to retrieve the rows from active sheets
 *
 * @param {google.auth.OAuth2} auth An authorized OAuth2 client.
 */
function callAppsScript(auth) {
    var script = google.script('v1');
    if (DEBUG_LEVEL >= 1) console.log('Getting events from spreadsheet  "' + config.googledocurl + config.sheetid + '"');

    // Make the API request. The request object is included here as 'resource'.
    script.scripts.run({
            auth: auth,
            resource: {
                'devMode' : true,
                'function' : 'getDemoData',
                'parameters' : [config.sheetid]
            },
            scriptId: config.projectkey
        },
        function(err, resp) {
            if (err) {
                // The API encountered a problem before the script started executing.
                console.log('The API returned an error: ' + err + ' resp: ' + resp);
                return;
            }
            if (resp.error) {
                // The API executed, but the script returned an error.

                // Extract the first (and only) set of error details. The values of this
                // object are the script's 'errorMessage' and 'errorType', and an array of stack trce elements
                var error = resp.error.details[0];
                console.log('Script error message: ' + error.errorMessage);
                console.log('Script error stacktrace:');

                if (error.scriptStackTraceElements) {
                    // There may not be a stacktrace if the script didn't start executing.
                    for (var i = 0; i < error.scriptStackTraceElements.length; i++) {
                        var trace = error.scriptStackTraceElements[i];
                        console.log('\t%s: %s', trace.function, trace.lineNumber);
                    }
                }
            } else {
                // The call to the script function was successful
                var events = resp.response.result;
                if (DEBUG_LEVEL > 0) {console.log('Retreived "'+ events.length + '" events from spreadsheet with id "' + config.sheetid + '"');}

                if (Object.keys(events).length == 0) {
                    // No events were returned.
                    console.log('No events found. You must unhide at least one sheet.');
                } else {

                    if (config.writelocal && config.writelocal === true){
                        if (DEBUG_LEVEL > 0) console.log('Writing Events To Local Data File');
                        var fileName;

                        for (var a = 0; a < events.length; a++){
                            fileName = config.datadir+events[a].sheetName.replace(/\s/g,'-')+config.datasuffix;
                            writeEventsToFile(fileName, events[a],a)
                        }
                    } else {
                        if (DEBUG_LEVEL > 0) console.log('Not writing events to local data file. writelocal="'+ config.writelocal +'"');
                    }
                }

                // process events
                processEvents(events);
            }
        });
}

// process events from local xlsx or google sheets
function processEvents(events) {
    // print out events
    if (DEBUG_LEVEL == 3) console.log('Events to process are ' + JSON.stringify(events));

    // set variables
    var eventsSent=0;
    var now = new Date();
    var timeshift=0;
    var intervalSeconds=1;
    var skippedEvents=0;

    // for each event do some things.
    grazeAuthenticate( () =>{
        // now update entity_catalog until it goes!
        // open mysql connection
        connection.connect();

    //events.events.map(function(event,n){
    events.map(function(event,n){

        var replayDelay = 0;
        if(event.timeline_sequence){
            replayDelay = parseInt(event.timeline_sequence)-1;
        }

        // work out groupid for update of entity_catalog record
        var groupId = 2;

        if(event.competency){
            var groupId = groups.indexOf(event.competency);
            if(!groupId || (groupId<0) || (groupId>(groups.length-1))){groupId=2;}else{groupId++;}
        }

        // check for service or process in event and add via graze call
        if(event.process){
            grazeAddProcessOrService('addProcess',event.process);
            connection.query(`insert into entity_catalog (name,process,gid,cid) values ('${event.source}','${event.process}',${groupId},${groupId}) on duplicate key update process='${event.process}',gid=${groupId},cid=${groupId}`, (error,result) => { });
        }
        if(event.service){
            grazeAddProcessOrService('addService',event.service);
            connection.query(`insert into entity_catalog (name,service,gid,cid) values ('${event.source}','${event.service}',${groupId},${groupId}) on duplicate key update service='${event.service}',gid=${groupId},cid=${groupId}`, (error,result) => { });
        }

        event.severity = SEVERITY[event.severity.toLowerCase()];

        setTimeout((function(e,m){
            //if (DEBUG_LEVEL == 0) entertainment();
            if (!event.destination || event.destination != 1){
                if (DEBUG_LEVEL > 0) console.log('Sending Event To Moogsoft REST Lam::' + JSON.stringify(e));
                var nowEpoch = Math.floor(now.getTime()/1000);
                e.agent_time = ''+nowEpoch;
                postREST({events:[e]});
            }

            eventsSent++;

            if((eventsSent+skippedEvents)>=(events.length)){console.log('Closing socket connection(s)');}
        }).bind(null,event,n),(replayDelay*config.rate*1000));

        // close mysql connection
        //connection.end();
    });
    // close mysql connection
    connection.end();
});

}

// post function for sending events to REST LAM
function postREST(data){
    postOptions = {
        shared_secret: '',
        host: config.rest.hostname,
        port: config.rest.port,
        path: '/',
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
    };

    var postData = JSON.stringify(data)+'\n\n\n\n';
    postOptions.headers['Content-Length'] = postData.length;

    var request = http.request(postOptions, function(response) {
        var responseData = '';
        response.setEncoding('utf8');
        response.on('error', function(error){
            console.log(error);
        });

        response.on('data', function(data){
            responseData+=data;
        });

        response.on('end', function(){
            if(JSON.parse(responseData).response.processed==1){
                if (DEBUG_LEVEL > 0) console.log('http(s) response '+responseData);
            }else{
                if (DEBUG_LEVEL > 0) console.log('\n\n------------------------------\n\nhttp(s) response '+responseData+'\n\n'+postData+'\n\n------------------------------\n\n');
            }
        });
    });

    request.on('error', function(e){
        console.log(e);
    });

    request.write(postData);
    request.end();
}

function grazeAuthenticate(callback){

    var responseData = '';

    https.request({hostname:'localhost',path:'/graze/v1/authenticate?username=graze&password=graze',method:'GET',rejectUnauthorized:false}, (response) => {

        response.on('data', (data) => {responseData+=data;});
    response.on('end', () => {
        authToken = JSON.parse(responseData).auth_token;
    if (DEBUG_LEVEL > 0) console.log('authToken='+authToken);
    callback();
});

}).end();
}

function grazeAddProcessOrService(grazeMethodName,name){
    var responseData = '';
    var postData = JSON.stringify({auth_token:authToken,name:name,description:name})+'\n\n\n\n';

    var request = https.request({hostname:'localhost',path:'/graze/v1/'+grazeMethodName,method:'POST',headers: {'Content-Type': 'application/json', 'Content-Length': postData.length},rejectUnauthorized:false}, (response) => {

        response.on('data', (data) => {responseData+=data;});
    response.on('end', () => {
        //console.log('Add process or service response = ' + JSON.stringify(responseData));
    });
})

    request.write(postData);
    request.end();
}
