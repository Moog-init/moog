#!/usr/bin/env bash
node /usr/share/moogsoft/bin/utils/loadlabdata.js "$1"
